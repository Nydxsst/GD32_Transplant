/**
  ******************************************************************************
  * @author  Nydxsst
  * @version V1.0.0
  * @date    2020/01/24
  ******************************************************************************
	* @attention
	* ������õ�PA13.PA14.PA15.PB3.PB4������Ҫ��jlink
	* rcu_periph_clock_enable(RCU_AF);
	* gpio_pin_remap_config(GPIO_SWJ_SWDPENABLE_REMAP, ENABLE);
  ******************************************************************************
  */

#include "gd32e10x.h"
#include "ws2812b.h"

extern u32 WS2812B_ALL_COLOR[PIXEL_MAX];

int main(void)
{
	/* �ر�JLINK */
	rcu_periph_clock_enable(RCU_AF);
	gpio_pin_remap_config(GPIO_SWJ_SWDPENABLE_REMAP, ENABLE);
	/* �ж����ȼ�ѡ�� */
	nvic_priority_group_set(NVIC_PRIGROUP_PRE2_SUB2);
	/* �����ʼ�� */
	Delay_Init();
	Led_Init();
	Usart_Debug_Init(115200);
	WS2812_Init();
	
	printf("Start\r\n");
	
	WS2812B_ALL_COLOR[0] = 0x0F0F0F;//red
//	WS2812B_ALL_COLOR[1] = 0x000F00;//green
//	WS2812B_ALL_COLOR[2] = 0x00000F;//blue
//	WS2812B_ALL_COLOR[3] = 0x0F000F;//purple
//	WS2812B_ALL_COLOR[4] = 0x0F000F;
//	WS2812B_ALL_COLOR[5] = 0x0F000F;
//	WS2812B_ALL_COLOR[6] = 0x00000F;
	//WS2812B_ALL_COLOR[7] = 0x0F000F;
	WS2812_Refresh();
	
	while(1)
	{
		//SYSTEM_LED = !SYSTEM_LED;
		printf("GoOn\r\n");
		Delay_Ms(500);
	}
}
